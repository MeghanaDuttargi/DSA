

#define MEM_ALLOC_FAIL NULL
#define USER_NOT_REGISTERED 1
#define TRUE 0

#define MOB_SIZE 10
#define SIZE 20
#define USER_NOT_FOUND -1
#define INSUFFICIENT_BALANCE -1
#define TRANSACTION_UNSUCCESSFULL -1

#include<stdio.h>
#include<stdlib.h>


struct transaction
{
    int trans_id;
    float amount;
    char sender_mob_no;
    char rec_mob_no;
    struct transaction *next_trans;

};
typedef struct transaction Transaction;


struct bank_acc
{
    int bank_acc;
    float balance;
    char business_type;
    struct bank_acc *bank_ptr;
};
typedef struct bank_acc BankAccount;


struct user
{
    char mob_no;
    int is_active;

    BankAccount *acc;
    Transaction *trans;
    struct user *next_user;
};
typedef struct user User;


struct upi_app
{
    User *usr;
};
typedef struct upi_app UpiApp;



UpiApp * initialize_upi();
UpiApp * register_user(UpiApp *, char );
UpiApp * add_bank_acc(UpiApp *, char,int,int,int,float);

UpiApp *activate_account(UpiApp *, char);
int transfer_money(UpiApp *,char ,char , float);



