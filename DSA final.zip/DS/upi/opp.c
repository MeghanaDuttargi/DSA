#include "header.h"
#include <stdio.h>


UpiApp * initialize_upi()
{
    UpiApp *upi;
    upi = (UpiApp *) malloc(sizeof(UpiApp));
    if(NULL==upi)return MEM_ALLOC_FAIL;

    upi->usr=NULL;

    return upi;
}


UpiApp * register_user(UpiApp *upi, char mob_num )
{
    User*new_user;
    new_user=(User *) malloc(sizeof(User));
    if(NULL==new_user) return MEM_ALLOC_FAIL;
    new_user->mob_no=mob_num;
    new_user->next_user=upi->usr;
    upi->usr=new_user;
    return upi;

}


UpiApp * add_bank_acc(UpiApp *upi, char mob_num ,int acc_type,int acc_num,int secondar_acc_num,float balance)
{
    //User *user=(search_user(upi,mob_num));
    //if (NULL==user);return USER_NOT_REGISTERED;
    User *temp;
    for(temp=upi->usr;temp!=NULL;temp=temp->next_user){
        int a=(temp->mob_no);
        if(a==mob_num)
        {
            BankAccount*bank_account;
            bank_account=(BankAccount *) malloc(sizeof(BankAccount));

            bank_account->bank_acc=acc_num;
            bank_account->balance=balance;
            bank_account->business_type=acc_type;

            bank_account->bank_ptr=NULL;
            if(secondar_acc_num !=0)
            {
                BankAccount *bank_account2;
                bank_account2=(BankAccount *) malloc(sizeof(BankAccount));
                bank_account2->bank_acc=secondar_acc_num;
                bank_account2->business_type=acc_type;
                bank_account2->bank_ptr=NULL;
                bank_account->bank_ptr=bank_account2;
            }


            temp->acc=bank_account;
            return upi;
        }
    }
    return USER_NOT_REGISTERED;

}
UpiApp *activate_account(UpiApp *upi, char mob_no)
{
    User *temp;
    for(temp=upi->usr;temp!=NULL;temp=temp->next_user){
        if(mob_no==temp->mob_no){
            if(temp->acc!=NULL){
                temp->is_active=1;
                return upi;
            }
        }
    }
    return USER_NOT_FOUND;
}

int create_trans_id()
{
    int trans_id = (rand() % (9999 - 1000 + 1)) + 1000;
    return trans_id;
}

Transaction *get_transaction(float amount,char sender_mob,char rec_mob)
{
    Transaction *new_trans=(Transaction *)malloc(sizeof(Transaction));

    int trans_id=create_trans_id();
    new_trans->trans_id=trans_id;
    new_trans->amount=amount;
    new_trans->sender_mob_no=sender_mob;
    new_trans->rec_mob_no=rec_mob;

    return new_trans;
}

int transfer_money(UpiApp *upi,char rec_mob_no,char sender_mob_no, float amount)
{
    User *temp1,*temp2;
    Transaction *new_transaction;
    for(temp1=upi->usr;temp1!=NULL;temp1=temp1->next_user){
        if(temp1->mob_no==sender_mob_no){
            for(temp2=upi->usr;temp2!=NULL;temp2=temp2->next_user){
                if(temp2->mob_no==rec_mob_no){
                    if(temp1->acc->balance < amount) return INSUFFICIENT_BALANCE;

                    if(temp2->acc->business_type==1){
                        temp2->acc->balance+=amount*0.1;
                        temp1->acc->balance-=amount*0.1;
                    }
                    temp2->acc->balance+=amount;
                    temp1->acc->balance-=amount;

                    new_transaction=get_transaction(amount,sender_mob_no,rec_mob_no);
                    new_transaction->next_trans=temp2->trans;
                    temp2->trans=new_transaction;

                    new_transaction=get_transaction(amount,sender_mob_no,rec_mob_no);
                    new_transaction->next_trans=temp1->trans;
                    temp1->trans=new_transaction;

                    return upi;
                }
            }
        }
    }
    return TRANSACTION_UNSUCCESSFULL;
}
