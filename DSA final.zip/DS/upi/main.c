#include <assert.h>
#include "header.h"

int main() {
    // Initialize UPI app
    UpiApp *upi;
    upi= initialize_upi();
    assert(upi != NULL);  // Ensure UPI app is initialized

    upi = register_user(upi,'A');
    upi = register_user(upi,'B');



    assert(add_bank_acc(upi,'A',0,1234,2234,2000.0));
    assert(add_bank_acc(upi,'B',0,1111,1212,1000.0));
    assert(upi->usr->next_user->acc->business_type==0);
    assert(upi->usr->next_user->acc->bank_acc==1234);
    assert(upi->usr->next_user->acc->bank_ptr->bank_acc==2234);

    assert(add_bank_acc(upi,'C',1,1234,0,123)==USER_NOT_REGISTERED);

    assert(activate_account(upi,'B'));
    assert(activate_account(upi,'C')==USER_NOT_FOUND);
    assert(upi->usr->is_active==1);

    //assert(transfer_money(upi,'B','A',10)==INSUFFICIENT_BALANCE);
    assert(transfer_money(upi,'B','A',100.0));
    assert(upi->usr->acc->balance==1100.0);

    printf("%f",upi->usr->acc->balance);

    return 0;


}
