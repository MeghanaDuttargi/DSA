
#ifndef _EMP_HEADER_
#define _EMP_HEADER_

#include<stdlib.h>
#include<stdio.h>

#define FOUND 1
#define NOT_FOUND 0
#define FULL -1
#define SUCCESS 1
#define MEM_ALLOC_FAIL NULL
#define NAME_SIZE 10
#define DESIG_SIZE 15
#define MOBILE_SIZE 11
#define MAIL_SIZE 20
#define EXP_SIZE 5
#define RESULT_SIZE 30
struct result_set
{

    int result_status;
    char result_message[RESULT_SIZE];
};
typedef struct result_set Result;

typedef struct _salary_
{
    float basic, hra, da;
}Salary;

struct _employee_
{
    int emp_id;
    char emp_name[NAME_SIZE];
    char emp_desig[DESIG_SIZE];
    Salary emp_sal;
    char mobile[MOBILE_SIZE];
    char email_id[MAIL_SIZE];
};

typedef struct _employee_ Employee;



struct _firm_data_
{
    Employee *emp;
    int c_size, t_size;
};
typedef struct _firm_data_ Firm;

Firm * initialize_employee(int size);
int insert_employee(Firm *, Employee data);
int salary_greater_than_50k(Firm *);
Employee get_employee_details(Firm *, char *, Result *);

#endif // _EMP_HEADER
