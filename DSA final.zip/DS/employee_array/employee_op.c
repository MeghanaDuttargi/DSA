#include<stdlib.h>
#include<string.h>

#include "employee.h"

Firm * initialize_employee(int size)
{
    Firm *my_arr;

    my_arr = (Firm *)malloc(sizeof(Firm));

    if(NULL == my_arr) return MEM_ALLOC_FAIL;

    my_arr->c_size = 0;
    my_arr->t_size = size;
    my_arr->emp = (Employee *)malloc(sizeof(Employee) * size);

    if(my_arr->emp == NULL){
        free(my_arr);
        return MEM_ALLOC_FAIL;
    }
    return my_arr;
}
int insert_employee(Firm *my_arr, Employee data)
{
     if(my_arr->c_size == my_arr->t_size) return FULL;

    *(my_arr->emp + my_arr->c_size) = data;
    my_arr->c_size++;

    return SUCCESS;
}

int salary_greater_than_50k(Firm *my_firm)
{
    int i, count=0;
    for(i=0; i<my_firm->c_size;i++)
    if((my_firm->emp+i)->emp_sal.basic + \
       (my_firm->emp+i)->emp_sal.hra + \
       (my_firm->emp+i)->emp_sal.da >= 50000)
        count++;
    return count;

}

Employee get_employee_details(Firm *my_firm, char *name, Result *res)
{
    int i;
    Employee emp;

    for(i=0; i<my_firm->c_size;i++)
    {
        if(!strcmp((my_firm->emp + i)->emp_name,name)){
            mempcpy(&emp, my_firm->emp+i,sizeof(Employee));
            (*res).result_status = FOUND;
        }
    }
    (*res).result_status = NOT_FOUND;
    return emp;
}
