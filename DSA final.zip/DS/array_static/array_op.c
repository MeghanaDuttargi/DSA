#include "array.h"

Array initialize_array(int size)
{
    Array my_array;

    my_array.c_size = 0;
    my_array.t_size = size > 0 && size < MAX_SIZE? size: MAX_SIZE;

    /*
    if(size > 0 && size < MAX_SIZE)
        my_array.t_size = size;
    else
        my_array.t_size = MAX_SIZE;
        */


    return my_array;

}

int is_full(Array my_arr)
{
    return my_arr.c_size == my_arr.t_size;
}

Array insert_elements(Array my_arr, int data, int *res)
{
    if(is_full(my_arr))
        *res = FULL;
    else{
        my_arr.array[my_arr.c_size++] = data;
        *res = SUCCESS;
        }
    return my_arr;
}


int search_element(Array my_arr, int element)
{
    int i;



    for(i=0; i<my_arr.c_size;i++)
        if(my_arr.array[i] == element) return FOUND;

    return NOT_FOUND;
}
int sum_of_elements(Array my_arr)
{
    int i, sum=0;

    for(i = 0; i< my_arr.c_size; i++)
        sum += my_arr.array[i];
    return sum;
}
