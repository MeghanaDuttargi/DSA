#include<assert.h>

#include "array.h"

int main()
{
    Array test_array, temp_arr;
    int result;

    test_array = initialize_array(5);
    temp_arr = initialize_array(40);

    assert(test_array.c_size == 0 && test_array.t_size == 5);
    assert(temp_arr.c_size == 0 && temp_arr.t_size == MAX_SIZE);

   test_array = insert_elements(test_array, 10,&result);
   assert(result == SUCCESS);

   test_array = insert_elements(test_array, 20,&result);
   assert(result == SUCCESS);

   test_array = insert_elements(test_array, 30,&result);
   assert(result == SUCCESS);

   test_array = insert_elements(test_array, 40,&result);
   assert(result == SUCCESS);

   test_array = insert_elements(test_array, 50,&result);
   assert(result == SUCCESS);

   test_array = insert_elements(test_array, 60,&result);
   assert(result == FULL);

   assert(search_element(test_array, 40));
   assert(search_element(test_array, 10));
   assert(search_element(test_array, 20));
   assert(search_element(test_array, 50));
   assert(search_element(test_array, 30));
   assert(search_element(test_array, 60) == NOT_FOUND);;


   return 0;
}
