
#define MAX_SIZE 20
#define SUCCESS 1
#define FULL -1
#define EMPTY 0
#define FAIL 0
#define FOUND 1
#define NOT_FOUND 0

struct _array_
{
    int array[MAX_SIZE];
    int c_size, t_size;
};
typedef struct _array_ Array;

Array initialize_array(int size);
Array insert_elements(Array, int data, int *result);
void display(Array);
int sum_of_elements(Array);
int add(int, int);

// find subset (x,y) such that it sums to M
int find_subset(Array, int m);
int search_element(Array, int);


