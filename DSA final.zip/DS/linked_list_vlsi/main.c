#include <stdlib.h>
#include <assert.h>
#include "list.h"

void test_sort_insert();

int main()
{
    List *test;

    test = initialise_list();
    assert(test != LIST_ALLOC_FAIL);
    assert(test->head == NULL);
    assert(test->head == test->tail);
    assert(test->count == 0);

    assert(insert_at_end(test, 60));
     assert(test->head == test->tail);
    assert(insert_at_end(test, 70));
    assert(insert_at_end(test, 80));
    assert(insert_at_beg(test, 10));


    assert(insert_at_beg(test, 20));
    assert(insert_at_beg(test, 30));
    assert(insert_at_beg(test, 40));
    assert(insert_at_beg(test, 50));

    assert(test->count == 8);
    assert(test->head->data == 50);
    assert(test->tail->data == 80);
    assert(test->head->ptr->ptr->ptr->data == 20);

    assert(search(test, 10));
    assert(search(test, 80));
    assert(search(test, 40));
    assert(search(test, 90) == NOT_FOUND);

    assert(test->count == 8);
    assert(insert_after_element(test, 100, 80));
    assert(test->tail->data == 100);

    assert(insert_after_element(test, 120, 50));
    assert(test->head->ptr->data == 120);

    assert(insert_after_element(test, 150, 180) == FAIL);

    assert(test->count == 10);

    test_sort_insert();

    return 0;
}

void test_sort_insert()
{
    List *test;
    Node *temp;
    int i;

    test = initialise_list();
    assert(test->count == 0);

    assert(insert_and_sort(test, 20));
    assert(test->head  == test->tail);
    assert(test->head->data = 20);

    assert(insert_and_sort(test, 60));
    assert(test->tail->data == 60);

    assert(insert_and_sort(test, 10));
    assert(test->head->data == 10);

    assert(insert_and_sort(test, 50));
    assert(insert_and_sort(test, 30));
    assert(insert_and_sort(test, 40));
    assert(insert_and_sort(test, 70));

    assert(test->count == 7);

    //check if elements are sorted
    for(temp = test->head, i =10; i<=70;temp = temp->ptr, i += 10)
        assert(temp->data == i);

    //test for duplicate elements entry
    assert(insert_and_sort(test, 20));
    assert(test->head->ptr->ptr->data == 20);
}
