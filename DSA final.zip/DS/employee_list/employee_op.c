#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include "employee_list.h"


List * initialize_list()
{
    List *my_list;

    my_list = (List *)malloc(sizeof(List));
    if(NULL == my_list) return LIST_MEM_ALLOC_FAIL;

    my_list->head = my_list->tail = NULL;
    my_list->count = 0;

    return my_list;
}

Node *get_node(Employee data)
{
    Node *new_node;

    new_node = (Node *)malloc(sizeof(Node));
    if(NULL == new_node) return NODE_MEM_ALLOC_FAIL;

    new_node->data = data;
    new_node->ptr = NULL;

    return new_node;
}
int insert_at_beg(List *my_list, Employee data)
{
    Node *new_node;

    new_node = get_node(data);

    if(new_node == NULL) return NODE_MEM_ALLOC_FAIL;

    //check if list is empty
    if(my_list->count == 0)
        my_list->head = my_list->tail = new_node;
    else
    {
        new_node->ptr = my_list->head;
        my_list->head = new_node;
    }
    my_list->count++;

    return SUCCESS;
}

Employee search_employee_by_id(List *my_list, int id)
{
    Node *temp;
    Employee emp;
    if(my_list->count == 0) my_list->op_status = LIST_EMPTY;

    for(temp = my_list->head; temp != NULL; temp = temp->ptr)
        if((temp->data).emp_id == id) {
            my_list->op_status = FOUND;
            memcpy(&emp, &(temp->data),sizeof(Employee));
        }
    my_list->op_status = NOT_FOUND;
    return emp;
}
