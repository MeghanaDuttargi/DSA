#define LIST_MEM_ALLOC_FAIL NULL
#define NODE_MEM_ALLOC_FAIL 0
#define SUCCESS 1
#define FOUND 1
#define NOT_FOUND 0
#define FAIL -1
#define ELEMENT_NOT_FOUND -1
#define NAME_SIZE 12
#define DESIG_SIZE 20
#define LIST_EMPTY -1

struct _employee_
{
    int emp_id;
    char emp_name[NAME_SIZE];
    char emp_desig[DESIG_SIZE];
    float salary;
};

typedef struct _employee_ Employee;

struct _node_
{
    Employee data;
    struct _node_ *ptr;
};
typedef struct _node_ Node;


struct _linked_list_
{
    Node *head, *tail;
    int count;
    int op_status;
};
typedef struct _linked_list_ List;

List * initialize_list();
int insert_at_beg(List *, Employee);
Employee search_employee_by_id(List *, int);
