#include <stdio.h>
#include <stdlib.h>
#include<assert.h>
#include<string.h>
#include "employee.h"
int main()
{
    List *test_emp;
    Employee data;

    test_emp = initialise_list();
    assert(test_emp->head == NULL);
    assert(test_emp->count == 0);

    data.emp_id = 1001;
    strcpy(data.emp_name, "Raj");
    strcpy(data.emp_desig, "Manager");
    data.emp_salary = 50000;
    data.emp_on_role = 1;

    assert(insert_at_beg(test_emp, data));
    assert(test_emp->count == 1);
    assert((test_emp->head->data).emp_id == 1001);

    data.emp_id = 1002;
    strcpy(data.emp_name, "Rajan");
    strcpy(data.emp_desig, "Sr. Manager");
    data.emp_salary = 70000;
    data.emp_on_role = 1;

    assert(insert_at_beg(test_emp, data));
    assert(test_emp->count == 2);
    assert((test_emp->head->data).emp_id == 1002);


    data.emp_id = 1003;
    strcpy(data.emp_name, "Ranjani");
    strcpy(data.emp_desig, "CEO");
    data.emp_salary = 90000;
    data.emp_on_role = 1;

    assert(insert_at_beg(test_emp, data));
    assert(test_emp->count == 3);
    assert((test_emp->head->data).emp_id == 1003);


    data.emp_id = 1004;
    strcpy(data.emp_name, "Rajiv");
    strcpy(data.emp_desig, "Sr. Developer");
    data.emp_salary = 50000;
    data.emp_on_role = 1;

    assert(insert_at_beg(test_emp, data));
    assert(test_emp->count == 4);
    assert((test_emp->head->data).emp_id == 1004);


    data.emp_id = 1005;
    strcpy(data.emp_name, "Siya");
    strcpy(data.emp_desig, "Developer");
    data.emp_salary = 50000;
    data.emp_on_role = 1;

    assert(insert_at_beg(test_emp, data));
    assert(test_emp->count == 5);
    assert((test_emp->head->data).emp_id == 1005);


    data = search_employee(test_emp,"Raj");
    assert(test_emp->last_op_status == 1);
    assert(strcmp(data.emp_name, "Raj")== 0);
    assert(data.emp_id == 1001);

    return 0;
}
