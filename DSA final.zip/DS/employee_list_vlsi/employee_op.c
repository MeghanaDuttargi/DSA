#include <stdlib.h>
#include<assert.h>
#include<string.h>
#include "employee.h"

List *initialise_list()
{
    List *my_list = NULL;

    my_list = (List *)malloc(sizeof(List));
    if(NULL == my_list) return LIST_ALLOC_FAIL;

    my_list->head = my_list->tail = NULL;
    my_list->count = 0;

    return my_list;
}

Node *get_node(Employee data)
{
    Node *new_node;

    new_node = (Node *) malloc(sizeof(Node));
    if(NULL == new_node) return NODE_ALLOC_FAIL;

    new_node->data = data;
    new_node->ptr = NULL;

    return new_node;
}
int insert_at_beg(List *my_list, Employee data)
{
    Node *new_node;

    new_node = get_node(data);
    if(NULL == new_node) return FAIL;

    if(my_list->head == NULL)
        my_list->head = my_list->tail = new_node;
    else{
        new_node->ptr = my_list->head;
        my_list->head = new_node;
    }
    my_list->count++;

    return SUCCESS;
}
int insert_at_end(List *my_list, Employee data)
{
    Node *new_node;

    new_node = get_node(data);
    if(NULL == new_node) return FAIL;

    if(my_list->count == 0)
        my_list->head = my_list->tail = new_node;
    else{
        my_list->tail->ptr = new_node;
        my_list->tail = new_node;
    }
    my_list->count++;

    return SUCCESS;
}

Employee search_employee(List *emp_list, char *name)
{
    Node *temp = emp_list->head;
    Employee emp;// = {-1,"Invalid", "Invalid",-1,0};

    if(temp == NULL)
        emp_list->last_op_status = LIST_EMPTY;
    else
    {
        for(; temp != NULL; temp = temp->ptr)
        {
            if(strcmp((temp->data).emp_name, name) == 0)
            {
                emp_list->last_op_status = FOUND;
                return temp->data;

            }
        }
    }
    emp_list->last_op_status = NOT_FOUND;

    return emp;
}
/*

int sort(List *my_list)
{
    Node *i, *j;
    int temp;

    for(i=my_list->head; i != NULL; i = i->ptr)
    {
        for(j=my_list->head; j< j->ptr != my_list->tail; j = j->ptr)
        {
            if(j->data > j->ptr->data)
                swap(arr[j], arr[j+1]);
        }
    }
}
*/
