#include <stdlib.h>
#include<stdio.h>
#include<assert.h>
#include "array.h"

int main()
{
    Array *one, *two, *new_array;

    one = initialize_array(10);
    two = initialize_array(15);

    assert(one != MEM_ALLOC_FAIL);
    assert(two != MEM_ALLOC_FAIL);

    assert(one->c_size == 0 && one->t_size == 10);
    assert(two->c_size == 0 && two->t_size == 15);

    assert(insert_data(one, 10) == SUCCESS);
    assert(insert_data(one, 40) == SUCCESS);
    assert(insert_data(one, 20) == SUCCESS);
    assert(insert_data(one, 40) == SUCCESS);
    assert(insert_data(one, 10) == SUCCESS);
    assert(insert_data(one, 20) == SUCCESS);
    assert(insert_data(one, 70) == SUCCESS);

    assert(one->c_size == 7);
  //  assert(*(one->arr + 4) == 50);

    assert(insert_data(two,10));
    assert(insert_data(two,20));
    assert(insert_data(two,30));
    assert(insert_data(two,40));
    assert(insert_data(two,50));
    assert(insert_data(two,60));
    assert(insert_data(two,70));
    assert(insert_data(two,80));

    assert(two->c_size == 8);

/*
    // Merge array B to A
    assert(merge_array(one, two));
    assert(one->t_size == 15);
    assert(one->c_size == 15);
    assert(*(one->arr + 14) == 80);
    assert(*(one->arr + 7) == 10);
*/
/*
    //Split array at index postion
    //10, 20, 30 40 50 60 70 10, 20, 30 40 50 60 70 80
    new_array = split_array(one, 10);

     //one = 10, 20, 30 40 50 60 70 10, 20, 30 ; new_arr = 40 50 60 70 80
    assert(new_array->c_size == 5);
    assert(one->c_size == 10);
     assert(*(one->arr + one->c_size -1) == 30);

    assert(*(new_array->arr) == 40);
    assert(*(new_array->arr+ new_array->c_size -1) == 80);

    assert(search(one, 50));
    assert(search(one, 90) == NOT_FOUND);
*/
    //set intersection of two arrays
    new_array = set_intersection(one, two);
    assert(new_array->c_size == 4);

  // display(one);
   printf("\n");
   sort(one);
   display(one);
    return 0;
}
