#define LIST_ALLOC_FAIL NULL
#define NODE_ALLOC_FAIL NULL
#define SUCCESS 1
#define FAIL 0
#define FOUND 1
#define NOT_FOUND 0
#define LIST_EMPTY 0
#define LIST_NOT_INIT -1

struct _max_min_
{
    int max, min;
};
typedef struct _max_min_ Maxmin;

struct _node_
{
    int data;
    struct _node_ *ptr;
};
typedef struct _node_ Node;

struct _linked_list_
{
    Node *head, *tail;
    int count;
};
typedef struct _linked_list_ List;

List *initialise_list();
int insert_at_beg(List *, int);
int insert_at_end(List *, int);
int insert_after_element(List *, int, int element);
int insert_after_pos(List *, int, int pos);
int insert_and_sort(List *, int);
int delete_at_beg(List *);
int delete_at_end(List *);
int delete_element(List *, int element);
int delete_at_pos(List *, int pos);
int delete_all_occurence(List *, int element);
int count_occurence(List *,int element);

int search(List *, int);
Maxmin max_min_list(List *);
int bubble_sort(List *);
List * intersection(List *, List *);
int merge_list(List *, List *);
