#include <stdlib.h>
#include<assert.h>
#include "list.h"

List *initialise_list()
{
    List *my_list = NULL;

    my_list = (List *)malloc(sizeof(List));
    if(NULL == my_list) return LIST_ALLOC_FAIL;

    my_list->head = my_list->tail = NULL;
    my_list->count = 0;

    return my_list;
}

Node *get_node(int data)
{
    Node *new_node;

    new_node = (Node *) malloc(sizeof(Node));
    if(NULL == new_node) return NODE_ALLOC_FAIL;

    new_node->data = data;
    new_node->ptr = NULL;

    return new_node;
}
int insert_at_beg(List *my_list, int data)
{
    Node *new_node;

    new_node = get_node(data);
    if(NULL == new_node) return FAIL;

    if(my_list->head == NULL)
        my_list->head = my_list->tail = new_node;
    else{
        new_node->ptr = my_list->head;
        my_list->head = new_node;
    }
    my_list->count++;

    return SUCCESS;
}
int insert_at_end(List *my_list, int data)
{
    Node *new_node;

    new_node = get_node(data);
    if(NULL == new_node) return FAIL;

    if(my_list->count == 0)
        my_list->head = my_list->tail = new_node;
    else{
        my_list->tail->ptr = new_node;
        my_list->tail = new_node;
    }
    my_list->count++;

    return SUCCESS;
}

int search(List *my_list, int element)
{
    Node *temp;

    for(temp = my_list->head; temp != NULL; temp = temp->ptr)
        if(temp->data == element) return FOUND;
    return NOT_FOUND;
}

int insert_after_element(List *my_list, int data, int element)
{
    Node *new_node, *temp;

    if(my_list == NULL || my_list->count == 0) return FAIL;

    if(my_list->tail->data == element)
        return insert_at_end(my_list, data);

    for(temp = my_list->head; \
        temp != my_list->tail && temp->data != element; \
        temp = temp->ptr);

    if(temp == my_list->tail) return FAIL;

    new_node = get_node(data);

    new_node->ptr = temp->ptr;
    temp->ptr = new_node;
    my_list->count++;

    return SUCCESS;

}
int insert_after_pos(List *, int, int pos); // practice

Node *get_element_address(List *my_list, int data)
{
    Node *temp;

    for(temp = my_list->head;\
      temp != my_list->tail && temp->ptr->data < data;\
      temp = temp->ptr);

    return temp;
}
void connect_node(Node *new_node,Node *temp)
{
    new_node->ptr = temp->ptr;
    temp->ptr = new_node;
}

int insert_and_sort(List *my_list, int data)
{
    Node *temp, *new_node;

    if(my_list == NULL) return FAIL;

    if(my_list->count == 0 || my_list->head->data >= data)
        return insert_at_beg(my_list, data);
    if(my_list->tail->data <= data)
        return insert_at_end(my_list, data);

    //return the address of node after which new data has to be inserted
    temp = get_element_address(my_list, data);

    //if element not found
    if(temp == my_list->tail) return NOT_FOUND;

    new_node = get_node(data);//create a new node
    //function to insert new_node after a element. Same function can
    // reused in insert_after_element
    connect_node(new_node, temp);
    my_list->count++;

    return SUCCESS;
}
int delete_at_beg(List *my_list)
{
    Node * temp = my_list->head;
    //if list is empty return LIST_EMPTY
    if(my_list->count == 0)
        return LIST_EMPTY;

    //check if list has one node then update head and tail to NULL
    if(my_list->count == 1)
        my_list->head = my_list->tail = NULL;
    //move the head to next node and free previous head
    else
        my_list->head = my_list->head->ptr;

     free(temp);
    //decrement the count
     my_list->count--;
    //return SUCCESS
     return SUCCESS;
}


int delete_at_end(List *my_list)
{
    Node *temp = my_list->head;
    // if list is empty
    if(my_list->count == 0) return LIST_EMPTY;
    //if list has one element
    if(my_list->count == 1){
        my_list->head = my_list->tail = NULL;
        free(temp);
    }
    // traverse till last but one node
    else{
        for(; temp->ptr != my_list->tail; temp = temp->ptr);
        free(temp->ptr);
        my_list->tail = temp;
        my_list->tail->ptr = NULL;
    }
    my_list->count--;

    return SUCCESS;

}
int delete_element(List *my_list, int element)
{
    Node *temp, *prev;

    //check if list is empty
    if(my_list->count == 0) return LIST_EMPTY;

    // check element is at head
    if(my_list->head->data == element)
        return delete_at_beg(my_list);

    //check if element is at tail
    if(my_list->tail->data == element)
        return delete_at_end(my_list);

    //search for element
    for(prev= my_list->head, temp= my_list->head->ptr;\
        temp != my_list->tail && temp->data != element;\
        prev = temp, temp = temp->ptr);

    //check if element found
    if(temp == my_list->tail) return NOT_FOUND;

    prev->ptr = temp->ptr;
    free(temp);
    my_list->count--;

    return SUCCESS;
}

int delete_all_occurence(List *my_list, int element)
{
    if(my_list->count == 0) return LIST_EMPTY;

    int count = count_occurence(my_list, element);

    if(count == 0) return NOT_FOUND;

    while(count-- > 0)
        assert(delete_element(my_list, element));

    return SUCCESS;
}

int count_occurence(List *my_list,int element)
{
    Node *temp = my_list->head;
    int count = 0;

    while(temp != NULL)
    {
        if(temp->data == element)
            count++;
        temp=temp->ptr;
    }
    return count;
}
