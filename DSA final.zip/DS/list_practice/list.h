#define NODE_MEM_ALLOC_FAIL NULL
#define COURSE_MEM_ALLOC_FAIL NULL
#define NODE_ALLOC_FAILED -1

struct student
{
    int id;
    char name[10];
    float cgpa;
    char email[20];
    char contact[11];
};

typedef struct student Student;

struct node
{
    Student data;
    struct node *ptr;
};
typedef struct node Node;

struct linked_list
{
    Node *head, *tail;
    int count;
    int total_intake;
    char course_name[20];
    int init_regno;
};
typedef struct linked_list Course_list;

Course_list * initialise_course(int, char *, int);

int insert_student(Course_list *, Student data);
int search_student(Course_list *, int reg_no);
