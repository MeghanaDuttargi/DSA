#include <stdio.h>
#include <stdlib.h>
#include<assert.h>
#include<string.h>
#include "list.h"

int main()
{
    Course_list *cyber, *es, *vlsi;
    Student data;

    cyber = initialise_course(30,"Cyber_Security", 241059001);
    vlsi = initialise_course(35,"VLSI",241036001);
    es = initialise_course(20, "ES",241037001);


    data.cgpa = 9.2;
    strcpy(data.name, "Kia");
    strcpy(data.contact,"9987657822");
    strcpy(data.email,"xyz@ge.com");

    assert(insert_student(cyber, data));
    assert((cyber->head->data).id == 241059001);


    data.cgpa = 8.2;
    strcpy(data.name, "Kiara");
    strcpy(data.contact,"8986873223");
    strcpy(data.email,"abc@ge.com");

    assert(insert_student(cyber, data));
    assert((cyber->tail->data).id == 241059002);
    assert(cyber->count == 2);

    return 0;
}
