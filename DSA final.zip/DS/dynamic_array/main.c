#include <stdlib.h>
#include<assert.h>
#include "array.h"

int main()
{
    Array *one, *two;

    one = initialize_array(10);
    two = initialize_array(10);

    assert(one != MEM_ALLOC_FAIL);
    assert(two != MEM_ALLOC_FAIL);

    assert(one->c_size == 0 && one->t_size == 10);
    assert(two->c_size == 0 && two->t_size == 10);

    assert(insert_data(one, 10) == SUCCESS);
    assert(insert_data(one, 20) == SUCCESS);
    assert(insert_data(one, 30) == SUCCESS);
    assert(insert_data(one, 40) == SUCCESS);
    assert(insert_data(one, 50) == SUCCESS);
    assert(insert_data(one, 60) == SUCCESS);
    assert(insert_data(one, 70) == SUCCESS);
    assert(insert_data(one, 80) == SUCCESS);
    assert(insert_data(one, 90) == SUCCESS);
    assert(insert_data(one, 100) == SUCCESS);

    assert(insert_data(one, 110) == FULL);

    assert(*(one->arr + 4) == 50);

    return 0;
}
