
#include<stdlib.h>

#include "array.h"

Array * initialize_array(int size)
{
    Array *my_arr;

    my_arr = (Array *)malloc(sizeof(Array));

    if(NULL == my_arr) return MEM_ALLOC_FAIL;

    my_arr->c_size = 0;
    my_arr->t_size = size;
    my_arr->arr = (int *)malloc(sizeof(int) * size);

    if(my_arr->arr == NULL){
        free(my_arr);
        return MEM_ALLOC_FAIL;
    }
    return my_arr;
}


int insert_data(Array *my_arr, int data)
{
    if(my_arr->c_size == my_arr->t_size) return FULL;

    *(my_arr->arr + my_arr->c_size) = data;
    my_arr->c_size++;

    return SUCCESS;
}
