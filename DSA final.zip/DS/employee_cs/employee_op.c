#include<stdlib.h>
#include<string.h>
#include "employee.h"

Company * initialize_company(int size)
{
     Company *my_arr;

    my_arr = (Company *)malloc(sizeof(Company));

    if(NULL == my_arr) return MEM_ALLOC_FAIL;

    my_arr->c_size = 0;
    my_arr->t_size = size;
    my_arr->emp = (Employee *)malloc(sizeof(Employee) * size);

    if(my_arr->emp == NULL){
        free(my_arr);
        return MEM_ALLOC_FAIL;
    }
    return my_arr;
}
int insert_employee(Company *my_arr, Employee data)
{
    if(my_arr->c_size == my_arr->t_size) return FULL;

    *(my_arr->emp + my_arr->c_size) = data;
    my_arr->c_size++;

    return SUCCESS;
}
Employee search_employee(Company *my_arr, int id)
{
    int i;
    Employee emp;

    for(i=0; i<my_arr->c_size;i++){
        if((my_arr->emp+i)->emp_id == id)
        memcpy(&emp,(my_arr->emp+i),sizeof(Employee));
    }
    return emp;
}

