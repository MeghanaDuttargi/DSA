#include<stdlib.h>
#include<assert.h>
#include<string.h>
#include "employee.h"

int main()
{
    Company *test;
    Employee data;

    test = initialize_company(5);
    assert(test->c_size == 0 && test->t_size == 5);
    assert(test->emp != MEM_ALLOC_FAIL);

    data.emp_id = 1001;
    strcpy(data.emp_name, "Avi");
    strcpy(data.emp_desig,"Manager");
    strcpy(data.email_id,"xyz@dc.com");
    strcpy(data.mobile,"998785676");
    data.emp_sal.basic = 10000;
    data.emp_sal.hra = 4000;
    data.emp_sal.da = 3000;
    assert(insert_employee(test,data));

    assert((test->emp + 0)->emp_id == 1001);

    data.emp_id = 1002;
    strcpy(data.emp_name, "Avinash");
    strcpy(data.emp_desig,"Sr.Manager");
    strcpy(data.email_id,"avi@dc.com");
    strcpy(data.mobile,"998sd5676");
    data.emp_sal.basic = 50000;
    data.emp_sal.hra = 5000;
    data.emp_sal.da = 3000;
    assert(insert_employee(test,data));

    assert((test->emp + 1)->emp_id == 1002);

    data.emp_id = 1003;
    strcpy(data.emp_name, "Manvi");
    strcpy(data.emp_desig,"CEO");
    strcpy(data.email_id,"ceo@dc.com");
    strcpy(data.mobile,"994335676");
    data.emp_sal.basic = 100000;
    data.emp_sal.hra = 40000;
    data.emp_sal.da = 30000;
    assert(insert_employee(test,data));

    assert((test->emp + 2)->emp_id == 1003);

    data.emp_id = 1004;
    strcpy(data.emp_name, "Palvi");
    strcpy(data.emp_desig,"Manager");
    strcpy(data.email_id,"palvi@dc.com");
    strcpy(data.mobile,"9987sd676");
    data.emp_sal.basic = 70000;
    data.emp_sal.hra = 14000;
    data.emp_sal.da = 3000;
    assert(insert_employee(test,data));

    assert((test->emp + 3)->emp_id == 1004);

    data.emp_id = 1005;
    strcpy(data.emp_name, "Ravi");
    strcpy(data.emp_desig,"Sr. Manager");
    strcpy(data.email_id,"ravi@dc.com");
    strcpy(data.mobile,"922785676");
    data.emp_sal.basic = 70000;
    data.emp_sal.hra = 4000;
    data.emp_sal.da = 3000;
    assert(insert_employee(test,data));

    assert((test->emp + 4)->emp_id == 1005);

    data.emp_id = 1006;
    strcpy(data.emp_name, "Kavi");
    strcpy(data.emp_desig,"Manager");
    strcpy(data.email_id,"xyz@dc.com");
    strcpy(data.mobile,"998785676");
    data.emp_sal.basic = 10000;
    data.emp_sal.hra = 4000;
    data.emp_sal.da = 3000;
    assert(insert_employee(test,data) == FULL);


    data = search_employee(test,1003);
    assert(data.emp_id == 1003);
    assert(!strcmp(data.emp_name,"Manvi"));


    return 0;
}
