#ifndef _EMPLOYEE_HEADER_
#define _EMPLOYEE_HEADER_


#define FULL -1
#define SUCCESS 1
#define MEM_ALLOC_FAIL NULL
#define NAME_SIZE 10
#define DESIG_SIZE 20
#define MOBILE_SIZE 11
#define MAIL_SIZE 20

typedef struct _salary_
{
    float basic, hra, da;
}Salary;

struct _employee_
{
    int emp_id;
    char emp_name[NAME_SIZE];
    char emp_desig[DESIG_SIZE];
    Salary emp_sal;
    int department;
    char mobile[MOBILE_SIZE];
    char email_id[MAIL_SIZE];
};
typedef struct _employee_ Employee;

struct company_
{
    Employee *emp;
    int c_size, t_size;
};
typedef struct company_ Company;

Company * initialize_company(int);
int insert_employee(Company *, Employee data);
Employee search_employee(Company *, int emp_id);

#endif // _EMPLOYEE_HEADER_


