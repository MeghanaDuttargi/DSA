#define LIST_ALLOC_FAIL NULL
#define NODE_ALLOC_FAIL NULL
#define SUCCESS 1
#define FAIL 0
#define FOUND 1
#define NOT_FOUND 0
#define LIST_EMPTY 0
#define LIST_NOT_INIT -1
#define NAME_SIZE 12
#define DESIG_SIZE 15

struct _employee_
{
    int emp_id;
    int emp_age;
    char emp_name[NAME_SIZE];
    char emp_desig[DESIG_SIZE];
    int report_to_emp;
    float emp_salary;
    int emp_on_role; // 1 - yes; 0 -No
};

typedef struct _employee_ Employee;

struct _node_
{
    Employee data;
    struct _node_ *ptr;
};

typedef struct _node_ Node;

struct _linked_list_
{
    Node *head, *tail;
    int last_op_status;
    int count;
};
typedef struct _linked_list_ List;

List *initialise_list();
int insert_at_beg(List *, Employee);
int insert_at_end(List *, Employee);
Employee search_employee(List *, char *);
// Assignment
int terminate_employee(List *, int emp_id);
float total_compensation(List *);
Employee max_sal(List *);
int sort_by_age(List *);
