
#define MEM_ALLOC_FAIL NULL
#define FULL -1
#define SUCCESS 1

struct _array_
{
    int *arr;
    int c_size, t_size;
};
typedef struct _array_ Array;

Array * initialize_array(int);
int insert_data(Array *, int);
int search(Array *, int);
int compare_array(Array *, Array *);
int sort(Array *);
int delete_element(Array *, int element);
int merge_array(Array *, Array *); //solve
Array * split_array(Array *, int index); // solve
int is_palindrome(Array *);
int reverse_array(Array *);
Array * set_intersection(Array *, Array *);
int binary_search(Array *, int element);
