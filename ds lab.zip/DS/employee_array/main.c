#include <stdio.h>
#include <stdlib.h>
#include<assert.h>
#include<string.h>
#include "employee.h"

int main()
{
    Firm *test;
    Employee data;
    Result res;
    test = initialize_employee(5);

    data.emp_id = 1001;
    strcpy(data.emp_name,"Raj");
    strcpy(data.emp_desig, "Manager");
    strcpy(data.mobile,"9899875422");
    strcpy(data.email_id,"xyz@yu.com");
    data.emp_sal.basic = 10000;
    data.emp_sal.hra = 2000;
    data.emp_sal.da = 3000;

    assert(insert_employee(test, data));
    assert(test->emp->emp_id == 1001);


    data.emp_id = 1002;
    strcpy(data.emp_name,"Rajan");
    strcpy(data.emp_desig, "SE");
    strcpy(data.mobile,"9899325422");
    strcpy(data.email_id,"rajan@yu.com");
    data.emp_sal.basic = 40000;
    data.emp_sal.hra = 2000;
    data.emp_sal.da = 3000;

    assert(insert_employee(test, data));
    assert((test->emp +1)->emp_id == 1002);


    data.emp_id = 1003;
    strcpy(data.emp_name,"Alia");
    strcpy(data.emp_desig, "CEO");
    strcpy(data.mobile,"982375422");
    strcpy(data.email_id,"alia@yu.com");
    data.emp_sal.basic = 100000;
    data.emp_sal.hra = 20000;
    data.emp_sal.da = 30000;

    assert(insert_employee(test, data));
    assert((test->emp +2)->emp_id == 1003);


    data.emp_id = 1004;
    strcpy(data.emp_name,"Rajesh");
    strcpy(data.emp_desig, "SE");
    strcpy(data.mobile,"9823235422");
    strcpy(data.email_id,"rajesh@yu.com");
    data.emp_sal.basic = 50000;
    data.emp_sal.hra = 6000;
    data.emp_sal.da = 5000;

    assert(insert_employee(test, data));
    assert((test->emp +3)->emp_id == 1004);


    data.emp_id = 1005;
    strcpy(data.emp_name,"ajio");
    strcpy(data.emp_desig, "Manager");
    strcpy(data.mobile,"9899875422");
    strcpy(data.email_id,"ajio@yu.com");
    data.emp_sal.basic = 60000;
    data.emp_sal.hra = 7000;
    data.emp_sal.da = 4000;

    assert(insert_employee(test, data));
    assert((test->emp +4)->emp_id == 1005);

      data.emp_id = 1006;
    strcpy(data.emp_name,"ajio");
    strcpy(data.emp_desig, "Manager");
    strcpy(data.mobile,"9899875422");
    strcpy(data.email_id,"ajio@yu.com");
    data.emp_sal.basic = 60000;
    data.emp_sal.hra = 7000;
    data.emp_sal.da = 4000;

    assert(insert_employee(test, data) == FULL);
    assert((test->emp +4)->emp_id == 1005);

    assert(salary_greater_than_50k(test) == 3);

    data = get_employee_details(test,"Rajesh",&res);
    assert(data.emp_id == 1004);

    return 0;
}
