#include <stdio.h>
#include <stdlib.h>
#include<assert.h>
#include<string.h>
#include "employee_list.h"

int main()
{
    List *test_emp;
    Employee emp_data;

    test_emp = initialize_list();
    assert(test_emp->count == 0);

    emp_data.emp_id = 1001;
    strcpy(emp_data.emp_name, "Raj");
    strcpy(emp_data.emp_desig,"HR");
    emp_data.salary = 50000;
    assert(insert_at_beg(test_emp, emp_data));
    assert((test_emp->head->data).emp_id == 1001);


    emp_data.emp_id = 1002;
    strcpy(emp_data.emp_name, "Rajan");
    strcpy(emp_data.emp_desig,"HR-Assist");
    emp_data.salary = 30000;
    assert(insert_at_beg(test_emp, emp_data));
    assert((test_emp->head->data).emp_id == 1002);


    emp_data.emp_id = 1003;
    strcpy(emp_data.emp_name, "Rajani");
    strcpy(emp_data.emp_desig,"SE");
    emp_data.salary = 90000;
    assert(insert_at_beg(test_emp, emp_data));
    assert((test_emp->head->data).emp_id == 1003);


    emp_data.emp_id = 1004;
    strcpy(emp_data.emp_name, "Raju");
    strcpy(emp_data.emp_desig,"Manager");
    emp_data.salary = 90000;
    assert(insert_at_beg(test_emp, emp_data));
    assert((test_emp->head->data).emp_id == 1004);

    assert(test_emp->count == 4);
    assert(strcmp((test_emp->tail->data).emp_name,"Raj") == 0);
}
