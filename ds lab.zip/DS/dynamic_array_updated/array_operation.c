#include<stdio.h>
#include<stdlib.h>
#include <assert.h>
#include "array.h"

Array * initialize_array(int size)
{
    Array *my_arr;

    my_arr = (Array *)malloc(sizeof(Array));

    if(NULL == my_arr) return MEM_ALLOC_FAIL;

    my_arr->c_size = 0;
    my_arr->t_size = size;
    my_arr->arr = (int *)malloc(sizeof(int) * size);

    if(my_arr->arr == NULL){
        free(my_arr);
        return MEM_ALLOC_FAIL;
    }
    return my_arr;
}


int insert_data(Array *my_arr, int data)
{
    if(my_arr->c_size == my_arr->t_size) return FULL;

    *(my_arr->arr + my_arr->c_size) = data;
    my_arr->c_size++;

    return SUCCESS;
}

int search(Array *my_arr, int element)
{
    int i;

    for(i=0;i<my_arr->c_size;i++)
        if(*(my_arr->arr + i) == element) return FOUND;
    return NOT_FOUND;
}
int merge_array(Array *first_arr, Array *sec_arr)
{
    int updated_len, i;

    if(sec_arr->c_size == 0) return 1;


    updated_len = first_arr->c_size + sec_arr->c_size;

    first_arr->arr = realloc(first_arr->arr, sizeof(int) * updated_len);
    first_arr->t_size = updated_len;
    assert(updated_len == 15);
    assert(first_arr->t_size == 15);

    for(i=0; i<sec_arr->c_size;i++){
        assert(insert_data(first_arr,*(sec_arr->arr + i)));
    }

    return 1;
}

Array * split_array(Array *my_arr, int index)
{
    int i;
    Array *new_arr;

    if(index <= 0 && index >= my_arr->c_size) return OPERATION_FAIL;

    new_arr = initialize_array(my_arr->c_size - index);
    if(new_arr == NULL) return MEM_ALLOC_FAIL;

    for(i = index; i< my_arr->c_size; i++)
        assert(insert_data(new_arr, *(my_arr->arr + i)));
    my_arr->c_size = index;

    return new_arr;

}

void display(Array *my_arr)
{
    int i;

    for(i=0; i<my_arr->c_size; i++)
        printf("%d ",*(my_arr->arr +i));
}


Array * set_intersection(Array *one, Array *two)
{
    Array *new_array;
    int i, len;

    len = one->c_size < two->c_size?one->c_size:two->c_size;

    new_array = initialize_array(len);
    if(new_array == NULL) MEM_ALLOC_FAIL;

    for(i=0; i<one->c_size;i++)
        if(search(two, *(one->arr+i)) && !search(new_array, *(one->arr+i)))
            assert(insert_data(new_array, *(one->arr + i)));

    return new_array;

}

void swap(int *x, int *y)
{
    int temp;

    temp = *x;
    *x = *y;
    *y = temp;
}

int sort(Array *my_arr)
{
    int i, j;

    for(i=0;i<my_arr->c_size;i++)
    {
        for(j=0;j<my_arr->c_size -i- 1;j++)
        {
            if(*(my_arr->arr + j) > *(my_arr->arr + j +1))
            {
                swap(my_arr->arr + j, my_arr->arr + j +1);
            }
        }
    }
    return SUCCESS;
}
