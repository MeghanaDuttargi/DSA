#include<stdlib.h>
#include<string.h>
#include "list.h"

Course_list * initialise_course(int total_intake, char *course_name, int base_reg)
{
    Course_list *my_list;

    my_list = (Course_list *)malloc(sizeof(Course_list));

    if(my_list == NULL) return COURSE_MEM_ALLOC_FAIL;

    my_list->head = my_list->tail = NULL;
    my_list->count = 0;
    my_list->total_intake = total_intake;
    strcpy(my_list->course_name, course_name);
    my_list->init_regno = base_reg;

    return my_list;
}
Node * get_student_node(Student data, Course_list *my_course)
{
    Node *new_node;

    new_node = (Node *)malloc(sizeof(Node));

    if(new_node == NULL) return NODE_MEM_ALLOC_FAIL;

    new_node->data = data;
    (new_node->data).id = my_course->init_regno++;

    return new_node;
}

int insert_student(Course_list *stud_list, Student data)
{
    Node *new_stud;

    new_stud = get_student_node(data, stud_list);

    if(new_stud == NULL) return NODE_ALLOC_FAILED;

    if(stud_list->count == 0)
        stud_list->head = stud_list->tail = new_stud;
    else{
        stud_list->tail->ptr = new_stud;
        stud_list->tail = new_stud;
    }
    stud_list->count++;

    return 1;
}

